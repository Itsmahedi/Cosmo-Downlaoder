/**
 * ✦ Cosmo Downloader v1.0 — Chrome/Brave/Edge Service Worker (Manifest V3)
 * 
 * Handles:
 *  1. Native messaging connection (com.cosmodownloader.downloader / com.rustget.downloader)
 *  2. Local HTTP bridge fallback (http://127.0.0.1:42424)
 *  3. Download interception (all file types)
 *  4. Context menu ("Download with CosmoDownloader")
 *  5. Video stream interception
 *  6. Popup communication
 */

"use strict";

let nativePort = null;
let isConnected = false;
let interceptEnabled = true;
let interceptedCount = 0;

const HOST_NAMES = ["com.cosmodownloader.downloader", "com.rustget.downloader"];
let hostIndex = 0;

const INTERCEPT_EXTENSIONS = new Set([
  "zip", "rar", "7z", "tar", "gz", "bz2", "xz", "iso", "dmg", "cab",
  "exe", "msi", "apk", "deb", "rpm", "appimage", "pkg", "run",
  "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods",
  "mp4", "mkv", "avi", "mov", "wmv", "flv", "webm", "m4v", "mpg", "mpeg", "ts", "3gp",
  "mp3", "flac", "wav", "aac", "ogg", "wma", "m4a", "opus",
  "psd", "ai", "svg", "tif", "tiff", "bmp", "raw",
  "torrent", "magnet", "img", "vhd", "vmdk", "bin", "dat", "rom"
]);

const INTERCEPT_MIMES = new Set([
  "application/octet-stream", "application/x-msdownload", "application/x-msdos-program",
  "application/zip", "application/x-rar-compressed", "application/x-7z-compressed",
  "application/x-tar", "application/gzip", "application/x-bzip2",
  "application/x-iso9660-image", "application/pdf", "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "video/mp4", "video/x-matroska", "video/avi", "video/webm",
  "audio/mpeg", "audio/flac", "audio/wav", "audio/ogg", "application/x-bittorrent"
]);

const MIN_SIZE_TO_INTERCEPT = 10240;

function connectNativeHost() {
  const hostName = HOST_NAMES[hostIndex % HOST_NAMES.length];
  try {
    nativePort = chrome.runtime.connectNative(hostName);
    isConnected = true;

    nativePort.onMessage.addListener((msg) => {
      console.log("[CosmoDownloader] Host message:", msg);
    });

    nativePort.onDisconnect.addListener(() => {
      isConnected = false;
      nativePort = null;
      hostIndex++;
      setTimeout(connectNativeHost, 5000);
    });

    console.log(`[CosmoDownloader] Connected to native host: ${hostName}`);
  } catch (e) {
    isConnected = false;
    nativePort = null;
    hostIndex++;
    setTimeout(connectNativeHost, 5000);
  }
}

function sendToCosmo(data) {
  const bridgePayload = {
    url: data.url,
    filename: data.filename || null,
    cookies: data.cookies || null,
    referer: data.referrer || data.referer || null
  };

  // Always attempt local HTTP bridge first for instantaneous IDM popup response
  if (data.url) {
    fetch("http://127.0.0.1:42424/download", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(bridgePayload)
    })
    .then((r) => r.json())
    .then((res) => {
      if (res && res.success) {
        interceptedCount++;
      }
    })
    .catch(() => {
      // If local bridge is offline, send via native messaging host to launch CosmoDownloader
      if (nativePort && isConnected) {
        try {
          nativePort.postMessage(data);
          interceptedCount++;
        } catch (e) {
          isConnected = false;
        }
      }
    });

    return true;
  }

  if (nativePort && isConnected) {
    try {
      nativePort.postMessage(data);
      interceptedCount++;
      return true;
    } catch (e) {
      isConnected = false;
    }
  }

  return false;
}

function getExtension(urlOrFilename) {
  try {
    const pathname = new URL(urlOrFilename).pathname;
    const dot = pathname.lastIndexOf(".");
    if (dot !== -1) {
      return pathname.substring(dot + 1).toLowerCase().split(/[?#]/)[0];
    }
  } catch {
    const dot = urlOrFilename.lastIndexOf(".");
    if (dot !== -1) {
      return urlOrFilename.substring(dot + 1).toLowerCase();
    }
  }
  return "";
}

function shouldIntercept(downloadItem) {
  if (!interceptEnabled) return false;

  const url = downloadItem.url || "";
  if (url.startsWith("blob:") || url.startsWith("data:") || url.startsWith("chrome-extension:")) {
    return false;
  }

  const ext = getExtension(downloadItem.filename || url);
  if (ext && INTERCEPT_EXTENSIONS.has(ext)) return true;

  const mime = (downloadItem.mime || "").toLowerCase();
  if (mime && INTERCEPT_MIMES.has(mime)) return true;

  if (downloadItem.fileSize && downloadItem.fileSize > MIN_SIZE_TO_INTERCEPT) return true;
  if (downloadItem.totalBytes && downloadItem.totalBytes > MIN_SIZE_TO_INTERCEPT) return true;

  return true;
}

chrome.downloads.onCreated.addListener((downloadItem) => {
  if (!interceptEnabled) return;

  const url = downloadItem.url || "";
  if (url.startsWith("blob:") || url.startsWith("data:") || url.startsWith("chrome-extension:")) {
    return;
  }

  if (shouldIntercept(downloadItem)) {
    chrome.downloads.cancel(downloadItem.id, () => {
      chrome.downloads.erase({ id: downloadItem.id }, () => {});
    });

    const filename = downloadItem.filename
      ? downloadItem.filename.split(/[\\/]/).pop()
      : url.split("/").pop()?.split("?")[0] || "download";

    sendToCosmo({
      action: "download",
      url: url,
      filename: filename,
      fileSize: downloadItem.fileSize || downloadItem.totalBytes || -1,
      mime: downloadItem.mime || "",
      referrer: downloadItem.referrer || "",
    });

    console.log(`[CosmoDownloader] Intercepted: ${filename}`);
  }
});

// â”€â”€â”€ Context Menus â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "cosmo-download-link",
    title: "Download with CosmoDownloader",
    contexts: ["link"],
  });

  chrome.contextMenus.create({
    id: "cosmo-download-media",
    title: "Download media with CosmoDownloader",
    contexts: ["image", "video", "audio"],
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  let url = "";
  if (info.menuItemId === "cosmo-download-link") {
    url = info.linkUrl || "";
  } else if (info.menuItemId === "cosmo-download-media") {
    url = info.srcUrl || "";
  }

  if (url) {
    const filename = url.split("/").pop()?.split("?")[0] || "download";
    sendToCosmo({
      action: "download",
      url: url,
      filename: filename,
      referrer: tab?.url || "",
    });
  }
});

// â”€â”€â”€ Messages â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.action) {
    case "getStatus":
      if (isConnected) {
        sendResponse({
          connected: true,
          interceptEnabled: interceptEnabled,
          interceptedCount: interceptedCount,
        });
      } else {
        fetch("http://127.0.0.1:42424/health")
          .then((r) => r.json())
          .then((data) => {
            const ok = data && data.status === "ok";
            sendResponse({
              connected: ok,
              interceptEnabled: interceptEnabled,
              interceptedCount: interceptedCount,
            });
          })
          .catch(() => {
            sendResponse({
              connected: false,
              interceptEnabled: interceptEnabled,
              interceptedCount: interceptedCount,
            });
          });
      }
      return true;

    case "toggleIntercept":
      interceptEnabled = !interceptEnabled;
      chrome.storage.local.set({ interceptEnabled });
      sendResponse({ interceptEnabled });
      break;

    case "addUrl":
      if (message.url) {
        const filename = message.url.split("/").pop()?.split("?")[0] || "download";
        const sent = sendToCosmo({
          action: "download",
          url: message.url,
          filename: filename,
          referrer: "",
        });
        sendResponse({ success: sent });
      }
      break;

    case "downloadVideo":
      if (message.url) {
        const sent = sendToCosmo({
          action: "download",
          url: message.url,
          filename: message.filename || "",
          referrer: message.pageUrl || "",
        });
        sendResponse({ success: sent });
      }
      break;

    default:
      break;
  }
  return true;
});

chrome.storage.local.get("interceptEnabled", (result) => {
  if (result.interceptEnabled !== undefined) {
    interceptEnabled = result.interceptEnabled;
  }
});

connectNativeHost();
console.log("[Cosmo Downloader] Service worker active — v1.1.0");

