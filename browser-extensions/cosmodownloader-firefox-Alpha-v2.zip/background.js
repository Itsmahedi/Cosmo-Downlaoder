﻿/**
 * âœ¦ CosmoDownloader v2.5 â€” Firefox Background Script (Manifest V2)
 * 
 * Handles:
 *  1. Native messaging connection (com.cosmodownloader.downloader / com.rustget.downloader)
 *  2. Local HTTP bridge fallback (http://127.0.0.1:42424)
 *  3. Download interception (all file types)
 *  4. Context menu ("Download with CosmoDownloader")
 *  5. Video stream interception
 *  6. Popup communication
 */

"use strict";

let nativePort = null;
let isConnected = false;
let interceptEnabled = true;
let interceptedCount = 0;

const HOST_NAMES = ["com.cosmodownloader.downloader", "com.rustget.downloader"];
let hostIndex = 0;

// File extensions we always intercept
const INTERCEPT_EXTENSIONS = new Set([
  "zip", "rar", "7z", "tar", "gz", "bz2", "xz", "iso", "dmg", "cab",
  "exe", "msi", "apk", "deb", "rpm", "appimage", "pkg", "run",
  "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods",
  "mp4", "mkv", "avi", "mov", "wmv", "flv", "webm", "m4v", "mpg", "mpeg", "ts", "3gp",
  "mp3", "flac", "wav", "aac", "ogg", "wma", "m4a", "opus",
  "psd", "ai", "svg", "tif", "tiff", "bmp", "raw",
  "torrent", "magnet", "img", "vhd", "vmdk", "bin", "dat", "rom"
]);

const INTERCEPT_MIMES = new Set([
  "application/octet-stream", "application/x-msdownload", "application/x-msdos-program",
  "application/zip", "application/x-rar-compressed", "application/x-7z-compressed",
  "application/x-tar", "application/gzip", "application/x-bzip2",
  "application/x-iso9660-image", "application/pdf", "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "video/mp4", "video/x-matroska", "video/avi", "video/webm",
  "audio/mpeg", "audio/flac", "audio/wav", "audio/ogg", "application/x-bittorrent"
]);

const MIN_SIZE_TO_INTERCEPT = 10240;

// â”€â”€â”€ Native Messaging & HTTP Bridge â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

function connectNativeHost() {
  const hostName = HOST_NAMES[hostIndex % HOST_NAMES.length];
  try {
    nativePort = browser.runtime.connectNative(hostName);
    isConnected = true;

    nativePort.onMessage.addListener((msg) => {
      console.log("[CosmoDownloader] Message from host:", msg);
    });

    nativePort.onDisconnect.addListener((p) => {
      isConnected = false;
      nativePort = null;
      hostIndex++;
      setTimeout(connectNativeHost, 5000);
    });

    console.log(`[CosmoDownloader] Connected to native host: ${hostName}`);
  } catch (e) {
    isConnected = false;
    nativePort = null;
    hostIndex++;
    setTimeout(connectNativeHost, 5000);
  }
}

function sendToCosmo(data) {
  // Try Native Messaging first
  if (nativePort && isConnected) {
    try {
      nativePort.postMessage(data);
      interceptedCount++;
      return true;
    } catch (e) {
      isConnected = false;
    }
  }

  // Fallback to local HTTP bridge on 127.0.0.1:42424
  if (data.url) {
    fetch("http://127.0.0.1:42424/download", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url: data.url,
        filename: data.filename || null,
        cookies: data.cookies || null,
        referer: data.referrer || data.referer || null
      })
    })
    .then((r) => r.json())
    .then((res) => {
      if (res && res.success) {
        interceptedCount++;
      }
    })
    .catch(() => {});
    return true;
  }

  return false;
}

// â”€â”€â”€ Download Interception â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

function getExtension(urlOrFilename) {
  try {
    const pathname = new URL(urlOrFilename).pathname;
    const dot = pathname.lastIndexOf(".");
    if (dot !== -1) {
      return pathname.substring(dot + 1).toLowerCase().split(/[?#]/)[0];
    }
  } catch {
    const dot = urlOrFilename.lastIndexOf(".");
    if (dot !== -1) {
      return urlOrFilename.substring(dot + 1).toLowerCase();
    }
  }
  return "";
}

function shouldIntercept(downloadItem) {
  if (!interceptEnabled) return false;

  const url = downloadItem.url || "";
  if (url.startsWith("blob:") || url.startsWith("data:") || url.startsWith("moz-extension:")) {
    return false;
  }

  const ext = getExtension(downloadItem.filename || url);
  if (ext && INTERCEPT_EXTENSIONS.has(ext)) return true;

  const mime = (downloadItem.mime || "").toLowerCase();
  if (mime && INTERCEPT_MIMES.has(mime)) return true;

  if (downloadItem.fileSize && downloadItem.fileSize > MIN_SIZE_TO_INTERCEPT) return true;
  if (downloadItem.totalBytes && downloadItem.totalBytes > MIN_SIZE_TO_INTERCEPT) return true;

  return true;
}

browser.downloads.onCreated.addListener((downloadItem) => {
  if (!interceptEnabled) return;

  const url = downloadItem.url || "";
  if (url.startsWith("blob:") || url.startsWith("data:") || url.startsWith("moz-extension:")) {
    return;
  }

  if (shouldIntercept(downloadItem)) {
    browser.downloads.cancel(downloadItem.id).then(() => {
      browser.downloads.erase({ id: downloadItem.id });
    }).catch(() => {});

    const filename = downloadItem.filename
      ? downloadItem.filename.split(/[\\/]/).pop()
      : url.split("/").pop()?.split("?")[0] || "download";

    sendToCosmo({
      action: "download",
      url: url,
      filename: filename,
      fileSize: downloadItem.fileSize || downloadItem.totalBytes || -1,
      mime: downloadItem.mime || "",
      referrer: downloadItem.referrer || "",
    });

    console.log(`[CosmoDownloader] Intercepted: ${filename}`);
  }
});

browser.webRequest.onHeadersReceived.addListener(
  (details) => {
    if (!interceptEnabled) return;
    if (details.type !== "main_frame" && details.type !== "sub_frame") return;

    const headers = details.responseHeaders || [];
    let isAttachment = false;
    let filename = "";

    for (const header of headers) {
      const name = header.name.toLowerCase();
      if (name === "content-disposition") {
        const val = header.value || "";
        if (val.toLowerCase().includes("attachment")) {
          isAttachment = true;
          const match = val.match(/filename[*]?=(?:UTF-8''|"?)([^";]+)/i);
          if (match) filename = decodeURIComponent(match[1].replace(/"/g, ""));
        }
      }
    }

    if (isAttachment) {
      if (!filename) {
        filename = details.url.split("/").pop()?.split("?")[0] || "download";
      }

      sendToCosmo({
        action: "download",
        url: details.url,
        filename: filename,
        referrer: details.originUrl || details.documentUrl || "",
      });

      return { cancel: true };
    }
  },
  { urls: ["<all_urls>"] },
  ["blocking", "responseHeaders"]
);

// â”€â”€â”€ Context Menus â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

browser.contextMenus.create({
  id: "cosmo-download-link",
  title: "Download with CosmoDownloader",
  contexts: ["link"],
});

browser.contextMenus.create({
  id: "cosmo-download-media",
  title: "Download media with CosmoDownloader",
  contexts: ["image", "video", "audio"],
});

browser.contextMenus.onClicked.addListener((info, tab) => {
  let url = "";
  if (info.menuItemId === "cosmo-download-link") {
    url = info.linkUrl || "";
  } else if (info.menuItemId === "cosmo-download-media") {
    url = info.srcUrl || "";
  }

  if (url) {
    const filename = url.split("/").pop()?.split("?")[0] || "download";
    sendToCosmo({
      action: "download",
      url: url,
      filename: filename,
      referrer: tab?.url || "",
    });
  }
});

// â”€â”€â”€ Message Handling â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.action) {
    case "getStatus":
      // Check native status or HTTP health
      if (isConnected) {
        sendResponse({
          connected: true,
          interceptEnabled: interceptEnabled,
          interceptedCount: interceptedCount,
        });
      } else {
        fetch("http://127.0.0.1:42424/health")
          .then((r) => r.json())
          .then((data) => {
            const ok = data && data.status === "ok";
            sendResponse({
              connected: ok,
              interceptEnabled: interceptEnabled,
              interceptedCount: interceptedCount,
            });
          })
          .catch(() => {
            sendResponse({
              connected: false,
              interceptEnabled: interceptEnabled,
              interceptedCount: interceptedCount,
            });
          });
      }
      return true;

    case "toggleIntercept":
      interceptEnabled = !interceptEnabled;
      browser.storage.local.set({ interceptEnabled });
      sendResponse({ interceptEnabled });
      break;

    case "addUrl":
      if (message.url) {
        const filename = message.url.split("/").pop()?.split("?")[0] || "download";
        const sent = sendToCosmo({
          action: "download",
          url: message.url,
          filename: filename,
          referrer: "",
        });
        sendResponse({ success: sent });
      }
      break;

    case "downloadVideo":
      if (message.url) {
        const sent = sendToCosmo({
          action: "download",
          url: message.url,
          filename: message.filename || "",
          referrer: message.pageUrl || "",
        });
        sendResponse({ success: sent });
      }
      break;

    default:
      break;
  }
  return true;
});

// Restore settings
browser.storage.local.get("interceptEnabled").then((result) => {
  if (result.interceptEnabled !== undefined) {
    interceptEnabled = result.interceptEnabled;
  }
});

connectNativeHost();
console.log("[CosmoDownloader] Background script active â€” v2.5.0");

